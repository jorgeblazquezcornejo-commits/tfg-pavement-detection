Debido al peso de las imágenes, se sube una muestra de las 5 ultimas vueltas de la validación
